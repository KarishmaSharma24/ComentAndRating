

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <h1>Add Review</h1>
        <form action="<?php echo e(route('comment.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" id="bookId" name="book_id" value="<?php echo e($id); ?>" />

            <!-- <div class="col">
                <div class="rate">
                    <input type="radio" id="star5" class="rate" name="rating" value="5" />
                    <label for="star5" title="text">5 stars</label>
                    <input type="radio" id="star4" class="rate" name="rating" value="4" />
                    <label for="star4" title="text">4 stars</label>
                    <input type="radio" id="star3" class="rate" name="rating" value="3" />
                    <label for="star3" title="text">3 stars</label>
                    <input type="radio" id="star2" class="rate" name="rating" value="2">
                    <label for="star2" title="text">2 stars</label>
                    <input type="radio" id="star1" class="rate" name="rating" value="1" />
                    <label for="star1" title="text">1 star</label>
                </div>
            </div> -->
            <div class="col-md-12">
                <textarea class="form-control" placeholder="Leave a comment here" name="description" id="description" style="height: 100px; resize: none;"></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-danger"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="footer mt-2">
                <button type="submit" class="btn btn-primary" id="submitCommnet">Add</button>
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#datatable').DataTable({
            layout: {
                bottomEnd: {
                    paging: {
                        firstLast: false
                    }
                }
            }
        });


    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Interview\BookManagement\resources\views/backend/comment/create.blade.php ENDPATH**/ ?>