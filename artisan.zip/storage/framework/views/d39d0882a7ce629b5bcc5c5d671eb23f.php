<?php $__env->startSection('content'); ?>
<style>
    .rate {
        float: left;
        height: 46px;
        padding: 0 10px;
    }

    .rate:not(:checked)>input {
        position: absolute;
        display: none;
    }

    .rate:not(:checked)>label {
        float: right;
        width: 1em;
        overflow: hidden;
        white-space: nowrap;
        cursor: pointer;
        font-size: 30px;
        color: #ccc;
    }

    .rated:not(:checked)>label {
        float: right;
        width: 1em;
        overflow: hidden;
        white-space: nowrap;
        cursor: pointer;
        font-size: 30px;
        color: #ccc;
    }

    .rate:not(:checked)>label:before {
        content: '★ ';
    }

    .rate>input:checked~label {
        color: #ffc700;
    }

    .rate:not(:checked)>label:hover,
    .rate:not(:checked)>label:hover~label {
        color: #deb217;
    }

    .rate>input:checked+label:hover,
    .rate>input:checked+label:hover~label,
    .rate>input:checked~label:hover,
    .rate>input:checked~label:hover~label,
    .rate>label:hover~input:checked~label {
        color: #c59b08;
    }

    .star-rating-complete {
        color: #c59b08;
    }

    .rating-container .form-control:hover,
    .rating-container .form-control:focus {
        background: #fff;
        border: 1px solid #ced4da;
    }

    .rating-container textarea:focus,
    .rating-container input:focus {
        color: #000;
    }

    .rated {
        float: left;
        height: 46px;
        padding: 0 10px;
    }

    .rated:not(:checked)>input {
        position: absolute;
        display: none;
    }

    .rated:not(:checked)>label {
        float: right;
        width: 1em;
        overflow: hidden;
        white-space: nowrap;
        cursor: pointer;
        font-size: 30px;
        color: #ffc700;
    }

    .rated:not(:checked)>label:before {
        content: '★ ';
    }

    .rated>input:checked~label {
        color: #ffc700;
    }

    .rated:not(:checked)>label:hover,
    .rated:not(:checked)>label:hover~label {
        color: #deb217;
    }

    .rated>input:checked+label:hover,
    .rated>input:checked+label:hover~label,
    .rated>input:checked~label:hover,
    .rated>input:checked~label:hover~label,
    .rated>label:hover~input:checked~label {
        color: #c59b08;
    }

    table#datatable th:nth-child(5),
    table#datatable td:nth-child(5) {
        width: 250px;
        /* Adjust rating column width */
    }
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?>


                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session()->get('message')); ?>

                    </div>
                    <?php endif; ?>
                </div>

                <div class="card-body">


                    <!-- <?php echo e(__('You are logged in!')); ?> -->

                    <div class="row">
                        <table class="table table-hover" id="datatable">
                            <thead>
                                <tr>
                                    <th scope="col">S.No.</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Writer</th>
                                    <th scope="col">Description</th>
                                    <th scope="col">Rating</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $j=1; ?>
                                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr value="<?php echo e($book->id); ?>">
                                    <th><?php echo e($j++); ?></th>
                                    <td>

                                        <?php echo e($book->title); ?>

                                    </td>
                                    <td><?php echo e($book->writer); ?></td>
                                    <td><?php echo e($book->description); ?>  </td>
                                    <td>
                                        <div class="rate">
                                            <?php for($i = 5; $i >= 1; $i--): ?>
                                            <input type="radio" id="star<?php echo e($i); ?>-<?php echo e($book->id); ?>" class="rateClass" name="rating" data-id="<?php echo e($book->id); ?>" value="<?php echo e($i); ?>"
                                               
                                            <?php endfor; ?>

                                            <?php for($i = $book->user_book_rating; $i >= 1; $i--): ?>
                                            <input type="radio" id="star<?php echo e($i); ?>-<?php echo e($book->id); ?>" class="rateClass" name="rating" data-id="<?php echo e($book->id); ?>" value="<?php echo e($i); ?>" checked />
                                            <label for="star<?php echo e($i); ?>-<?php echo e($book->id); ?>" title="text"><?php echo e($i); ?> star<?php echo e($i > 1 ? 's' : ''); ?></label>
                                            <?php endfor; ?>
                                        </div>
                                    </td>
                                    <td>
                                        <button type="button" class="btn btn-primary comment text-white" id="comment"><a href="<?php echo e(route('comment.create', $book->id)); ?>" class="text-white">Comment</a>
                                        </button>
                                    </td>

                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#datatable').DataTable({
            layout: {
                bottomEnd: {
                    paging: {
                        firstLast: false
                    }
                }
            }
        });

        $('input.rateClass').on('click', function() {
            var rating = $(this).val();
            var bookId = $(this).data('id');
            console.log("bookId" + bookId);
            // console.log();

            $.ajax({
                url: "<?php echo e(route('rating.store')); ?>",
                type: 'POST',
                data: {
                    rating: rating,
                    book_id: bookId
                },
                success: function(response) {
                    console.log(response);
                    if (response.status == 200) {
                        alert('Rating submitted: ' + rating);
                    } else {
                        alert('Rating nto updated');
                    }
                    window.location.reload();

                },
                error: function(xhr) {

                    alert('An error occurred while submitting the rating.');
                }
            });
        });

    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Interview\BookManagement\resources\views/home.blade.php ENDPATH**/ ?>